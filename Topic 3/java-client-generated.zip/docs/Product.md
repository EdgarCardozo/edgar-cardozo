
# Product

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idProd** | **Integer** |  | 
**productName** | **String** |  | 
**quantity** | **String** |  | 
**price** | [**BigDecimal**](BigDecimal.md) |  | 



