# CartApi

All URIs are relative to *https://virtserver.swaggerhub.com/EdgarCardozo/ShoppingCart/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cartsGet**](CartApi.md#cartsGet) | **GET** /carts | Get all carts
[**cartsPost**](CartApi.md#cartsPost) | **POST** /carts | Add a new cart
[**cartsPut**](CartApi.md#cartsPut) | **PUT** /carts | Update an existing cart


<a name="cartsGet"></a>
# **cartsGet**
> List&lt;Cart&gt; cartsGet()

Get all carts

Returns a Cart

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CartApi;


CartApi apiInstance = new CartApi();
try {
    List<Cart> result = apiInstance.cartsGet();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling CartApi#cartsGet");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List&lt;Cart&gt;**](Cart.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="cartsPost"></a>
# **cartsPost**
> cartsPost(body)

Add a new cart

Add a new cart to the server

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CartApi;


CartApi apiInstance = new CartApi();
Cart body = new Cart(); // Cart | The cart that will be added to the shopping
try {
    apiInstance.cartsPost(body);
} catch (ApiException e) {
    System.err.println("Exception when calling CartApi#cartsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Cart**](Cart.md)| The cart that will be added to the shopping |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: aplication/json

<a name="cartsPut"></a>
# **cartsPut**
> cartsPut(body)

Update an existing cart

Update an existing cart

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.CartApi;


CartApi apiInstance = new CartApi();
Cart body = new Cart(); // Cart | The cart that will be added to the shopping
try {
    apiInstance.cartsPut(body);
} catch (ApiException e) {
    System.err.println("Exception when calling CartApi#cartsPut");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Cart**](Cart.md)| The cart that will be added to the shopping |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: aplication/json

