
# Cart

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idCart** | **Integer** |  | 
**products** | [**List&lt;Product&gt;**](Product.md) |  |  [optional]
**total** | [**BigDecimal**](BigDecimal.md) |  | 



